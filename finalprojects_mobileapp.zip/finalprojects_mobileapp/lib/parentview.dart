import 'package:flutter/material.dart';
import 'loginpageparent.dart';

void main() {
  runApp(const StudentPortalApp());
}

class StudentPortalApp extends StatelessWidget {
  const StudentPortalApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Student Portal',
      theme: ThemeData(primarySwatch: Colors.teal),
      home: const PortalTabPage(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class PortalTabPage extends StatelessWidget {
  const PortalTabPage({super.key});

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 5,
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.red.shade700,
          title: Row(
            children: [
              Image.asset(
                'assets/logocy.png',
                height: 35,
                width: 35,
                fit: BoxFit.cover,
                errorBuilder: (context, error, stackTrace) {
                  return const Icon(
                    Icons.image_not_supported,
                    color: Colors.white,
                  );
                },
              ),
              const SizedBox(width: 10),
              const Flexible(
                child: Text(
                  'CYREL LEARNING CENTER',
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 18,
                    color: Colors.white,
                  ),
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ],
          ),
          actions: [
            IconButton(
              icon: const Icon(Icons.logout, color: Colors.white),
              tooltip: 'Logout',
              onPressed: () {
                showDialog(
                  context: context,
                  builder: (context) => AlertDialog(
                    title: const Text('Confirm Logout'),
                    content: const Text('Are you sure you want to log out?'),
                    actions: [
                      TextButton(
                        onPressed: () => Navigator.of(context).pop(),
                        child: const Text('Cancel'),
                      ),
                      TextButton(
                        onPressed: () {
                          Navigator.of(context).pop(); // close dialog
                          Navigator.of(context).pushReplacement(
                            MaterialPageRoute(
                              builder: (_) => const LoginPage(),
                            ),
                          );
                        },
                        child: const Text('Logout'),
                      ),
                    ],
                  ),
                );
              },
            ),
          ],
          bottom: const TabBar(
            isScrollable: true,
            indicatorColor: Colors.black,
            labelColor: Colors.black,
            unselectedLabelColor: Colors.white,
            tabs: [
              Tab(text: 'Home'),
              Tab(text: 'Schedule'),
              Tab(text: 'Liabilities'),
              Tab(text: 'Student Profile'),
              Tab(text: 'Online Enrollment'),
            ],
          ),
        ),

        body: const TabBarView(
          children: [
            HomeTab(),
            ScheduleTab(),
            LiabilitiesTab(),
            StudentProfileTab(),
            OnlineEnrollmentTab(),
          ],
        ),
      ),
    );
  }
}

class HomeTab extends StatelessWidget {
  const HomeTab({super.key});

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: const Color.fromARGB(255, 216, 221, 221),
              borderRadius: BorderRadius.circular(16),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.1),
                  blurRadius: 10,
                  offset: const Offset(0, 5),
                ),
              ],
            ),
            child: const Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text.rich(
                  TextSpan(
                    text: 'Student Name: ',
                    style: TextStyle(fontSize: 18),
                    children: [
                      TextSpan(
                        text: 'Juan Dela Cruz',
                        style: TextStyle(fontWeight: FontWeight.bold),
                      ),
                    ],
                  ),
                ),
                SizedBox(height: 10),
                Text('Student ID: 202501234', style: TextStyle(fontSize: 18)),
                SizedBox(height: 10),
                Text('Section: Diamond', style: TextStyle(fontSize: 18)),
                SizedBox(height: 10),
                Text('Class: Nursery 2', style: TextStyle(fontSize: 18)),
              ],
            ),
          ),
          const SizedBox(height: 24),
          const Center(
            child: Text(
              'Announcements',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
          ),
          const SizedBox(height: 16),
          SizedBox(
            height: 300,
            child: ListView(
              scrollDirection: Axis.horizontal,
              children: [
                buildAnnouncementCard('assets/announcement1.jpg', width: 320),
                buildAnnouncementCard('assets/announcement2.jpg', width: 320),
                buildAnnouncementCard('assets/announcement3.jpg', width: 320),
              ],
            ),
          ),
          const SizedBox(height: 50),
          const Text(
            'About Cyrel Learning Center',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 10),
          const Text(
            'Cyrel and Michael, they didn’t start this learning center just for  '
            'business. They built it out of their deep desire as parents to see '
            'children learning while enjoying themselves. '
            'At Cyrel Learning Center, their mission is clear—building an '
            'environment where learning and play go hand in hand. Unlike'
            'typical schools that focus heavily on grades, excessive '
            'assignments, and standardized tests, Cyrel Learning Center '
            'champions the belief that every child has their own unique'
            'abilities. This means there’s no one-size-fits-all approach here.'
            'Every child receives a personalized experience. Every child is'
            'unique. Every child matters.',
            style: TextStyle(fontSize: 16),
            textAlign: TextAlign.justify,
          ),
        ],
      ),
    );
  }

  static Widget buildAnnouncementCard(String imagePath, {double width = 250}) {
    return Container(
      margin: const EdgeInsets.only(right: 12),
      width: width,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(12),
        image: DecorationImage(image: AssetImage(imagePath), fit: BoxFit.cover),
      ),
    );
  }
}

class ScheduleTab extends StatelessWidget {
  const ScheduleTab({super.key});

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Center(
        child: Column(
          children: [
            ElevatedButton.icon(
              onPressed: () {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text('Print functionality coming soon!'),
                  ),
                );
              },
              icon: const Icon(Icons.print),
              label: const Text('Print Schedule'),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.red.shade700,
                foregroundColor: Colors.white,
              ),
            ),
            const SizedBox(height: 20),
            Card(
              elevation: 6,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
              child: Container(
                padding: const EdgeInsets.all(16),
                color: Colors.grey.shade100,
                width: MediaQuery.of(context).size.width * 0.95,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    const Text(
                      'Schedule',
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        color: Colors.grey,
                      ),
                    ),
                    const SizedBox(height: 16),
                    SingleChildScrollView(
                      scrollDirection: Axis.horizontal,
                      child: DataTable(
                        headingRowColor: WidgetStateProperty.all(
                          Colors.red.shade700,
                        ),
                        headingTextStyle: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                        ),
                        columns: const [
                          DataColumn(label: Text('Day')),
                          DataColumn(label: Text('Classes')),
                          DataColumn(label: Text('Subject')),
                          DataColumn(label: Text('Time')),
                          DataColumn(label: Text('Instructor')),
                        ],
                        rows: const [
                          DataRow(
                            cells: [
                              DataCell(Text('Monday')),
                              DataCell(Text('Socialization')),
                              DataCell(Text('...')),
                              DataCell(Text('8:00am–10:00am')),
                              DataCell(
                                Text(
                                  'Ms. Rachel',
                                  style: TextStyle(fontWeight: FontWeight.bold),
                                ),
                              ),
                            ],
                          ),
                          DataRow(
                            cells: [
                              DataCell(Text('Monday')),
                              DataCell(Text('Pre-kindergarten')),
                              DataCell(Text('Filipino')),
                              DataCell(Text('8:00am–10:00am')),
                              DataCell(
                                Text(
                                  'Ms. Rachel',
                                  style: TextStyle(fontWeight: FontWeight.bold),
                                ),
                              ),
                            ],
                          ),
                          DataRow(
                            cells: [
                              DataCell(Text('Tuesday')),
                              DataCell(Text('...')),
                              DataCell(Text('Reading')),
                              DataCell(Text('10:00am–11:00am')),
                              DataCell(
                                Text(
                                  'Ms. Rachel',
                                  style: TextStyle(fontWeight: FontWeight.bold),
                                ),
                              ),
                            ],
                          ),
                          DataRow(
                            cells: [
                              DataCell(Text('Tuesday')),
                              DataCell(Text('Playground')),
                              DataCell(Text('...')),
                              DataCell(Text('8:00am–10:00am')),
                              DataCell(
                                Text(
                                  'Ms. Rachel',
                                  style: TextStyle(fontWeight: FontWeight.bold),
                                ),
                              ),
                            ],
                          ),
                          DataRow(
                            cells: [
                              DataCell(Text('Monday')),
                              DataCell(Text('Tutorial')),
                              DataCell(Text('...')),
                              DataCell(Text('8:00am–10:00am')),
                              DataCell(
                                Text(
                                  'Ms. Rachel',
                                  style: TextStyle(fontWeight: FontWeight.bold),
                                ),
                              ),
                            ],
                          ),
                        ],
                        border: TableBorder.all(
                          color: Colors.grey.shade400,
                          width: 1,
                        ),
                        dataRowHeight: 60,
                        headingRowHeight: 50,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class LiabilitiesTab extends StatelessWidget {
  const LiabilitiesTab({super.key});

  @override
  Widget build(BuildContext context) {
    final List<Map<String, dynamic>> liabilities = [
      {
        'qty': 1,
        'description': 'Tuition Fee',
        'unitPrice': 10000,
        'amount': 10000,
      },
      {
        'qty': 2,
        'description': 'Activity Fee',
        'unitPrice': 500,
        'amount': 1000,
      },
      {'qty': 1, 'description': 'Book Fee', 'unitPrice': 1200, 'amount': 1200},
      {
        'qty': 3,
        'description': 'Miscellaneous',
        'unitPrice': 300,
        'amount': 900,
      },
    ];

    final int total = liabilities.fold(
      0,
      (sum, item) => sum + item['amount'] as int,
    );

    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Center(
            child: ElevatedButton.icon(
              onPressed: () {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text('Print functionality coming soon!'),
                  ),
                );
              },
              icon: const Icon(Icons.print),
              label: const Text('Print Liabilities'),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.red.shade700,
                foregroundColor: Colors.white,
              ),
            ),
          ),
          const SizedBox(height: 20),
          const Center(
            child: Text(
              'Liabilities',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: Colors.grey,
              ),
            ),
          ),
          const SizedBox(height: 16),
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: Colors.red.shade700,
              borderRadius: const BorderRadius.only(
                topLeft: Radius.circular(12),
                topRight: Radius.circular(12),
              ),
            ),
            child: const Row(
              children: [
                Expanded(
                  child: Text(
                    'QTY',
                    style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                Expanded(
                  flex: 3,
                  child: Text(
                    'Description',
                    style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                Expanded(
                  child: Text(
                    'Unit Price',
                    style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                    ),
                    textAlign: TextAlign.right,
                  ),
                ),
                Expanded(
                  child: Text(
                    'Amount',
                    style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                    ),
                    textAlign: TextAlign.right,
                  ),
                ),
              ],
            ),
          ),
          ...liabilities.map((item) {
            return Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 14),
              decoration: BoxDecoration(
                color: Colors.teal.shade50,
                border: Border(bottom: BorderSide(color: Colors.grey.shade300)),
              ),
              child: Row(
                children: [
                  Expanded(child: Text('${item['qty']}')),
                  Expanded(flex: 3, child: Text(item['description'])),
                  Expanded(
                    child: Text(
                      '₱${item['unitPrice']}',
                      textAlign: TextAlign.right,
                    ),
                  ),
                  Expanded(
                    child: Text(
                      '₱${item['amount']}',
                      textAlign: TextAlign.right,
                    ),
                  ),
                ],
              ),
            );
          }).toList(),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 16),
            decoration: BoxDecoration(
              color: Colors.teal.shade100,
              borderRadius: const BorderRadius.only(
                bottomLeft: Radius.circular(12),
                bottomRight: Radius.circular(12),
              ),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                const Text(
                  'Total: ',
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                ),
                Text(
                  '₱$total',
                  style: const TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 18,
                    color: Colors.red,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class StudentProfileTab extends StatelessWidget {
  const StudentProfileTab({super.key});

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Center(
            child: ElevatedButton.icon(
              onPressed: () {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text('Print functionality coming soon!'),
                  ),
                );
              },
              icon: const Icon(Icons.print),
              label: const Text('Print Profile'),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.red.shade700,
                foregroundColor: Colors.white,
              ),
            ),
          ),
          const SizedBox(height: 20),
          const Text(
            'Student Profile',
            style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 20),
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: Image.asset(
                  'assets/logocy.png',
                  width: 100,
                  height: 100,
                  fit: BoxFit.cover,
                ),
              ),
              const SizedBox(width: 20),
              const Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text.rich(
                      TextSpan(
                        text: 'Student Name: ',
                        style: TextStyle(fontSize: 16),
                        children: [
                          TextSpan(
                            text: 'Juan Dela Cruz',
                            style: TextStyle(fontWeight: FontWeight.bold),
                          ),
                        ],
                      ),
                    ),
                    SizedBox(height: 10),
                    Text(
                      'Student ID: 202501234',
                      style: TextStyle(fontSize: 16),
                    ),
                    SizedBox(height: 10),
                    Text('Section: Diamond', style: TextStyle(fontSize: 16)),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 30),
          Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(12),
              color: Colors.grey.shade100,
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.05),
                  blurRadius: 5,
                  offset: Offset(0, 3),
                ),
              ],
            ),
            child: Table(
              border: TableBorder.all(color: Colors.grey.shade400),
              columnWidths: const {
                0: FlexColumnWidth(2),
                1: FlexColumnWidth(1),
              },
              children: const [
                TableRow(
                  children: [
                    Padding(
                      padding: EdgeInsets.all(12),
                      child: Text(
                        'Offer Classes',
                        style: TextStyle(fontWeight: FontWeight.bold),
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.all(12),
                      child: Text(
                        'Grades',
                        style: TextStyle(fontWeight: FontWeight.bold),
                      ),
                    ),
                  ],
                ),
                TableRow(
                  children: [
                    Padding(
                      padding: EdgeInsets.all(12),
                      child: Text('Socialization'),
                    ),
                    Padding(
                      padding: EdgeInsets.all(12),
                      child: Text('A', textAlign: TextAlign.center),
                    ),
                  ],
                ),
                TableRow(
                  children: [
                    Padding(
                      padding: EdgeInsets.all(12),
                      child: Text('Pre Kindergarten'),
                    ),
                    Padding(
                      padding: EdgeInsets.all(12),
                      child: Text('A', textAlign: TextAlign.center),
                    ),
                  ],
                ),
                TableRow(
                  children: [
                    Padding(
                      padding: EdgeInsets.all(12),
                      child: Text('Playground'),
                    ),
                    Padding(
                      padding: EdgeInsets.all(12),
                      child: Text('B', textAlign: TextAlign.center),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class OnlineEnrollmentTab extends StatefulWidget {
  const OnlineEnrollmentTab({super.key});

  @override
  State<OnlineEnrollmentTab> createState() => _OnlineEnrollmentTabState();
}

class _OnlineEnrollmentTabState extends State<OnlineEnrollmentTab> {
  final _formKey = GlobalKey<FormState>();

  final TextEditingController _firstname = TextEditingController();
  final TextEditingController _middlename = TextEditingController();
  final TextEditingController _lastname = TextEditingController();
  final TextEditingController _dob = TextEditingController();
  final TextEditingController _phone = TextEditingController();
  final TextEditingController _class = TextEditingController();
  final TextEditingController _age = TextEditingController();
  final TextEditingController _address = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Form(
        key: _formKey,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Text(
              'Online Enrollment',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 20),
            buildTextField(_firstname, 'Firstname'),
            buildTextField(_middlename, 'Middle name'),
            buildTextField(_lastname, 'Lastname'),
            buildTextField(_dob, 'Date of Birth'),
            buildTextField(
              _phone,
              'Phone Number',
              keyboardType: TextInputType.phone,
            ),
            buildTextField(_class, 'Class'),
            buildTextField(_age, 'Age', keyboardType: TextInputType.number),
            buildTextField(_address, 'Address'),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                if (_formKey.currentState!.validate()) {
                  showDialog(
                    context: context,
                    builder: (context) => AlertDialog(
                      title: const Text('Enrollment Submitted'),
                      content: const Text(
                        'Thank you for enrolling again at Cyrel Learning Center.',
                      ),
                      actions: [
                        TextButton(
                          onPressed: () => Navigator.of(context).pop(),
                          child: const Text('OK'),
                        ),
                      ],
                    ),
                  );

                  _firstname.clear();
                  _middlename.clear();
                  _lastname.clear();
                  _dob.clear();
                  _phone.clear();
                  _class.clear();
                  _age.clear();
                  _address.clear();
                }
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.red.shade700,
                padding: const EdgeInsets.symmetric(
                  horizontal: 40,
                  vertical: 16,
                ),
              ),
              child: const Text('Enroll'),
            ),
          ],
        ),
      ),
    );
  }

  Widget buildTextField(
    TextEditingController controller,
    String label, {
    TextInputType keyboardType = TextInputType.text,
  }) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: TextFormField(
        controller: controller,
        keyboardType: keyboardType,
        decoration: InputDecoration(
          labelText: label,
          border: const OutlineInputBorder(),
          filled: true,
          fillColor: Colors.grey.shade200,
        ),
        validator: (value) =>
            value == null || value.isEmpty ? 'Required' : null,
      ),
    );
  }
}
