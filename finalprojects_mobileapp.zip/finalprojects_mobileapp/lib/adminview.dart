import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Cyrel Learning Center',
      theme: ThemeData(primarySwatch: Colors.teal),
      home: const HomePage(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFFC8102E),
        title: const Text('CYREL LEARNING CENTER'),
      ),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: const [
            DrawerHeader(
              decoration: BoxDecoration(color: Color(0xFFC8102E)),
              child: Text(
                'User Roles',
                style: TextStyle(color: Colors.white, fontSize: 24),
              ),
            ),
            RoleTile(title: 'Teacher', page: TeacherPage()),
            RoleTile(title: 'Head Admin', page: HeadAdminPage()),
            RoleTile(title: 'School Admin', page: SchoolAdminPage()),
          ],
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              const Text(
                'Announcements',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 20),
              SizedBox(
                height: 400,
                child: Center(
                  child: ListView(
                    scrollDirection: Axis.horizontal,
                    shrinkWrap: true,
                    children: [
                      buildAnnouncementCard('assets/announcement1.jpg'),
                      buildAnnouncementCard('assets/announcement2.jpg'),
                      buildAnnouncementCard('assets/announcement3.jpg'),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 50),
              const Text(
                'About Cyrel Learning Center',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 9),
              const Text(
                'Cyrel and Michael, they didn’t start this learning center just for '
                'business. They built it out of their deep desire as parents to see '
                'children learning while enjoying themselves. '
                'At Cyrel Learning Center, their mission is clear—building an '
                'environment where learning and play go hand in hand. Unlike '
                'typical schools that focus heavily on grades, excessive '
                'assignments, and standardized tests, Cyrel Learning Center '
                'champions the belief that every child has their own unique '
                'abilities. This means there’s no one-size-fits-all approach here. '
                'Every child receives a personalized experience. Every child is '
                'unique. Every child matters.',
                style: TextStyle(fontSize: 16),
                textAlign: TextAlign.justify,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

Widget buildAnnouncementCard(String imagePath, {double width = 500}) {
  return Center(
    child: Container(
      margin: const EdgeInsets.symmetric(horizontal: 12),
      width: width,
      height: 500,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(12),
        image: DecorationImage(image: AssetImage(imagePath), fit: BoxFit.cover),
      ),
    ),
  );
}

class RoleTile extends StatelessWidget {
  final String title;
  final Widget page;

  const RoleTile({super.key, required this.title, required this.page});

  @override
  Widget build(BuildContext context) {
    return ListTile(
      leading: const Icon(Icons.person, color: Colors.black87),
      title: Text(title),
      onTap: () {
        Navigator.pop(context);
        Navigator.push(context, MaterialPageRoute(builder: (context) => page));
      },
    );
  }
}

class TeacherPage extends StatelessWidget {
  const TeacherPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Teacher Dashboard')),
      body: const Center(child: Text('Welcome, Teacher')),
    );
  }
}

class HeadAdminPage extends StatelessWidget {
  const HeadAdminPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Head Admin Panel')),
      body: const Center(child: Text('Welcome, Head Admin')),
    );
  }
}

class SchoolAdminPage extends StatelessWidget {
  const SchoolAdminPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('School Admin Dashboard')),
      body: const Center(child: Text('Welcome, School Admin')),
    );
  }
}
