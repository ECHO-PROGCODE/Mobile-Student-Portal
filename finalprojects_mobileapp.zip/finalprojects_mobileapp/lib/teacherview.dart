import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Teacher Portal',
      theme: ThemeData(primarySwatch: Colors.red),
      home: const TeacherPage(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class TeacherPage extends StatefulWidget {
  const TeacherPage({super.key});

  @override
  State<TeacherPage> createState() => _TeacherPageState();
}

class _TeacherPageState extends State<TeacherPage> {
  int _selectedIndex = 0;

  final List<Widget> _pages = const [
    TeacherHomeTab(),
    TeacherScheduleTab(),
    TeacherStudentTab(),
    TeacherGradesTab(),
  ];

  final List<String> _titles = ['Home', 'Schedule', 'Student', 'Grades'];

  void _onTabTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(_titles[_selectedIndex]),
        backgroundColor: const Color(0xFFC8102E),
      ),
      body: _pages[_selectedIndex],
      bottomNavigationBar: BottomNavigationBar(
        selectedItemColor: Colors.redAccent,
        unselectedItemColor: Colors.grey,
        currentIndex: _selectedIndex,
        onTap: _onTabTapped,
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Home'),
          BottomNavigationBarItem(
            icon: Icon(Icons.schedule),
            label: 'Schedule',
          ),
          BottomNavigationBarItem(icon: Icon(Icons.people), label: 'Student'),
          BottomNavigationBarItem(icon: Icon(Icons.grade), label: 'Grades'),
        ],
      ),
    );
  }
}

class TeacherHomeTab extends StatelessWidget {
  const TeacherHomeTab({super.key});

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: const Color.fromARGB(255, 216, 221, 221),
              borderRadius: BorderRadius.circular(16),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.1),
                  blurRadius: 10,
                  offset: const Offset(0, 5),
                ),
              ],
            ),
            child: const Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text.rich(
                  TextSpan(
                    text: 'Teacher Name: ',
                    style: TextStyle(fontSize: 18),
                    children: [
                      TextSpan(
                        text: 'Mr. Juan Dela Cruz',
                        style: TextStyle(fontWeight: FontWeight.bold),
                      ),
                    ],
                  ),
                ),
                SizedBox(height: 10),
                Text('Employee ID: T202500123', style: TextStyle(fontSize: 18)),
                SizedBox(height: 10),
                Text(
                  'Department: Kindergarten',
                  style: TextStyle(fontSize: 18),
                ),
              ],
            ),
          ),
          const SizedBox(height: 24),
          const Center(
            child: Text(
              'Announcements',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
          ),
          const SizedBox(height: 16),
          SizedBox(
            height: 300,
            child: ListView(
              scrollDirection: Axis.horizontal,
              children: const [
                AnnouncementCard(imagePath: 'assets/announcement1.jpg'),
                AnnouncementCard(imagePath: 'assets/announcement2.jpg'),
                AnnouncementCard(imagePath: 'assets/announcement3.jpg'),
              ],
            ),
          ),
          const SizedBox(height: 50),
          const Text(
            'About Cyrel Learning Center',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 10),
          const Text(
            'Cyrel and Michael, they didn’t start this learning center just for '
            'business. They built it out of their deep desire as parents to see '
            'children learning while enjoying themselves. At Cyrel Learning Center, '
            'their mission is clear—building an environment where learning and play '
            'go hand in hand. Unlike typical schools that focus heavily on grades, '
            'excessive assignments, and standardized tests, Cyrel Learning Center '
            'champions the belief that every child has their own unique abilities. '
            'This means there’s no one-size-fits-all approach here. Every child '
            'receives a personalized experience. Every child is unique. Every child matters.',
            style: TextStyle(fontSize: 16),
            textAlign: TextAlign.justify,
          ),
        ],
      ),
    );
  }
}

class AnnouncementCard extends StatelessWidget {
  final String imagePath;

  const AnnouncementCard({super.key, required this.imagePath});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 300,
      margin: const EdgeInsets.only(right: 12),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(16),
        image: DecorationImage(image: AssetImage(imagePath), fit: BoxFit.cover),
      ),
    );
  }
}

class TeacherScheduleTab extends StatelessWidget {
  const TeacherScheduleTab({super.key});

  @override
  Widget build(BuildContext context) {
    return const Center(child: Text('Here is your schedule'));
  }
}

class TeacherStudentTab extends StatelessWidget {
  const TeacherStudentTab({super.key});

  @override
  Widget build(BuildContext context) {
    return const Center(child: Text('List of students appears here'));
  }
}

class TeacherGradesTab extends StatelessWidget {
  const TeacherGradesTab({super.key});

  @override
  Widget build(BuildContext context) {
    return const Center(child: Text('Student grades shown here'));
  }
}
