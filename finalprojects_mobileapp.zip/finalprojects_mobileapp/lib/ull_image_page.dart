import 'package:flutter/material.dart';

class FullImagePage extends StatelessWidget {
  final String imagePath;

  const FullImagePage({super.key, required this.imagePath});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Full Image'),
        backgroundColor: Colors.red.shade700,
      ),
      body: Center(child: Image.asset(imagePath, fit: BoxFit.contain)),
    );
  }
}
